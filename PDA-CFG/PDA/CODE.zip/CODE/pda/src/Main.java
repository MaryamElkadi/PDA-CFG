import java.io.*;
import java.util.Stack;

public class Main {

    private static final int[][][][] transitions = {
            // Transitions for PDA1
            {{{1, 2}, {0, 2}},
                    {{3, 4}, {}},
                    {{}, {5, 6}},
                    {{}, {7}},
                    {{8}, {7}},
                    {{5, 6}, {7}},
                    {{}, {9}},
                    {{8}, {}},
                    {{}, {}},
                    {{}, {9}}},

            // Transitions for PDA2
            {{{1}, {}},
                    {{2}, {}},
                    {{2, 3}, {}},
                    {{2}, {4}},
                    {{5}, {}},
                    {{5, 6}, {}},
                    {{5}, {7}}},

            // Transitions for PDA3
            {{{1}, {}},
                    {{1, 2}, {2}},
                    {{}, {3}},
                    {{}, {}}},

            // Transitions for PDA4
            {{{1}, {}},
                    {{1, 2}, {}},
                    {{3}, {3}},
                    {{3}, {4}},
                    {{4}, {5}},
                    {{5}, {}}}
    };

    public static boolean accept(String input, int pdaNumber) {
        Stack<Integer> stack = new Stack<>();
        stack.push(0); // Initial state

        for (char c : input.toCharArray()) {
            int currentState = stack.peek();

            int inputSymbol;

            switch (pdaNumber) {
                case 1:
                    inputSymbol = (c == 'a') ? 0 : ((c == 'b') ? 1 : -1);
                    break;
                case 2:
                    inputSymbol = (c == 'a') ? 0 : ((c == 'b') ? 1 : -1);
                    break;
                case 3:
                    inputSymbol = (c == '{') ? 0 : ((c == '}') ? 1 : -1);
                    break;
                case 4:
                    inputSymbol = (c == 'a') ? 0 : ((c == 'b') ? 1 : ((c == 'c') ? 2 : -1));
                    break;
                default:
                    inputSymbol = -1; // Default case for unrecognized input symbols
            }

            if (inputSymbol == -1) {
                // Handle unrecognized input symbols
                continue; // Skip processing this character
            }

            // Check if the transition array index is valid
            if (currentState >= transitions[pdaNumber - 1].length ||
                    inputSymbol >= transitions[pdaNumber - 1][currentState].length ||
                    transitions[pdaNumber - 1][currentState][inputSymbol] == null) {
                return false;
            }

            for (int nextState : transitions[pdaNumber - 1][currentState][inputSymbol]) {
                stack.push(nextState);
            }
        }

        // Check if the stack is in a final state
        int currentState = stack.peek();
        return currentState == transitions[pdaNumber - 1].length - 1;
    }



    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
            BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");

                // Skip empty lines or lines containing only whitespace
                if (parts.length == 0 || parts[0].isEmpty()) {
                    continue;
                }

                int pdaNumber = Integer.parseInt(parts[0]);
                StringBuilder inputBuilder = new StringBuilder();

                // Read input lines until "end" is encountered or the next PDA number
                while ((line = reader.readLine()) != null && !line.equals("end")) {
                    // Check if the line starts with a digit (new PDA number)
                    if (Character.isDigit(line.charAt(0))) {
                        break;
                    }
                    inputBuilder.append(line).append("\n");
                }

                String input = inputBuilder.toString().trim(); // Remove trailing newline

                // Process input for the current PDA
                boolean accepted = accept(input, pdaNumber);

                // Write PDA number followed by acceptance result for the input
                writer.write(pdaNumber + "\n");
                writer.write((accepted ? "accepted\n" : "not accepted\n"));
            }

            // Write "end" after processing all PDAs
            writer.write("end\n");

            reader.close();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
